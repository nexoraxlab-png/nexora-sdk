# Nexora Affiliate Automation SDK – v1 (secure edition)

This repository contains a TypeScript‑based SDK for automating affiliate content workflows.  It exposes a simple HTTP API built with Express and provides abstractions for content generation, workflow orchestration and third‑party integrations.  The code is designed to be deployed on a Node.js hosting platform (such as [Render](https://render.com)) without requiring you to run any terminal commands locally.

## Getting started

1. **Set up your environment variables**

   Copy the `.env.example` file to `.env` and fill in your own secrets.  At a minimum you should set:

   - `INTERNAL_API_KEY` – a strong secret used to protect all `/api/**` routes.  Requests must send this value in the `x-api-key` header.
   - `OPENAI_API_KEY` – your OpenAI API key (if you plan to use AI‑powered content generators).
   - `N8N_WEBHOOK_URL` – the URL of your internal n8n webhook that proxies calls to third‑party services.  The SDK never calls external APIs directly.

   Optional integrations for TikTok, YouTube, Pinterest, ClickBank and PartnerStack are also exposed.  Leave those variables blank unless you plan to configure them later.

2. **Run the server locally** (for advanced users)

   If you have Node.js 18+ installed, you can run the service locally:

   ```bash
   npm install      # install dependencies
   npm run build    # transpile TypeScript into the `dist` folder
   npm start        # start the HTTP server (defaults to port 4000)
   ```

   The health check is available at `GET /health` and returns a simple JSON object.  All other `/api/**` endpoints require the `x-api-key` header.

3. **Deploy on Render**

   To deploy on [Render](https://render.com), create a new **Web Service** and point it at this repository or upload the ZIP provided with this SDK.  Use the following settings:

   - **Build command**: `npm install && npm run build`
   - **Start command**: `npm start`
   - **Environment**: Node.js 18
   - **Environment variables**: configure the variables defined in `.env.example` via Render’s environment tab.  Do **not** commit real secrets to source control.

   Render will install dependencies, compile the TypeScript code and start the server for you.

## Project structure

The main folders and files are:

| Path | Description |
| --- | --- |
| `src/api` | Express server, middleware and route definitions |
| `src/config` | Environment typings and helper to read variables |
| `src/utils` | Simple logger, HTTP client wrapper and common types |
| `src/workflows` | Workflow definitions and execution engine |
| `src/scheduling` | Cron‑based scheduler for recurring tasks |
| `src/content` | Helper functions for generating captions and scripts |
| `src/integrations` | Abstractions for posting tasks to your n8n webhook |
| `src/automation` | Automation triggers and orchestrator |
| `.env.example` | Template for required environment variables |

You can import the SDK programmatically via:

```ts
import { NEXORA_SDK_VERSION, api, workflows } from 'nexora-sdk-v1-secure';
```

## Security considerations

This repository intentionally leaves all secrets undefined.  **Never** commit real API keys or secrets into version control.  Instead, rely on environment variables and configure them in your deployment platform.  The `INTERNAL_API_KEY` must be kept secret and should be rotated periodically.