/**
 * Describes a workflow definition.  Workflows encapsulate reusable logic and
 * expose a `run` function that accepts an input object and returns a result.
 */
export interface WorkflowDefinition {
  id: string;
  name: string;
  description?: string;
  // The main function executed when the workflow is run.  It receives an
  // arbitrary input object and returns a promise with the workflow result.
  run: (input?: any) => Promise<any>;
}