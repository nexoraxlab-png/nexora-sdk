import { workflows, getWorkflowById } from './registry';
import { WorkflowDefinition } from './types';
import { logger } from '../utils/logger';

/**
 * Returns an array of all available workflow definitions.  Consumers can use
 * this to display a list of workflows through the API.
 */
export function listWorkflows(): WorkflowDefinition[] {
  return workflows;
}

/**
 * Executes a workflow by its identifier.  The input is passed directly to
 * the workflow’s `run` function.  Logs execution start and end.
 *
 * @param id Identifier of the workflow to run
 * @param input Optional input object passed to the workflow
 */
export async function runWorkflowById(id: string, input?: any): Promise<any> {
  const workflow = getWorkflowById(id);
  if (!workflow) {
    throw new Error(`Workflow with id "${id}" not found`);
  }
  logger.info(`Executing workflow ${workflow.id}`, { input });
  const result = await workflow.run(input);
  logger.info(`Finished workflow ${workflow.id}`);
  return result;
}