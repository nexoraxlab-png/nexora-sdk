import { WorkflowDefinition } from './types';
import { generateAffiliateCaption } from '../content/caption';
import { generateVideoScriptOutline } from '../content/script';
import * as clickbank from '../integrations/clickbank';
import { logger } from '../utils/logger';

/**
 * Workflow definition that orchestrates the creation of affiliate content.  It
 * fetches available offers from the ClickBank integration, generates a video
 * script outline for the first offer and then produces a caption.  The input
 * object may optionally override the angle or platform used when generating
 * content.
 */
export const affiliateContentV1: WorkflowDefinition = {
  id: 'affiliate-content-v1',
  name: 'Affiliate Content Workflow v1',
  description:
    'Fetches a ClickBank offer and generates a script outline and caption for promotional content.',
  async run(input: { angle?: string; platform?: string } = {}): Promise<any> {
    logger.info('Running affiliate-content-v1 workflow');
    // Step 1: fetch offers from ClickBank via the n8n webhook
    const offersResponse = await clickbank.getOffers({});
    const offers = (offersResponse as any).offers || [];
    if (!offers.length) {
      throw new Error('No offers returned from ClickBank integration');
    }
    const offer = offers[0];
    const productName: string = offer.name || offer.title || 'Product';

    // Step 2: generate a video script outline for the offer
    const script = generateVideoScriptOutline({ productName, durationSeconds: 30 });

    // Step 3: generate an affiliate caption using provided angle/platform overrides
    const caption = generateAffiliateCaption({
      productName,
      angle: input.angle || 'general',
      platform: input.platform || 'tiktok'
    });

    // Return the aggregated result
    return { offer, script, caption };
  }
};