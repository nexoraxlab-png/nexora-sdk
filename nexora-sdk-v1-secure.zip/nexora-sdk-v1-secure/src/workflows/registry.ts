import { WorkflowDefinition } from './types';
import { affiliateContentV1 } from './affiliateContentV1';

// Collection of all workflow definitions available in this SDK.  Add new
// workflow modules here and export them via the default array.
export const workflows: WorkflowDefinition[] = [affiliateContentV1];

/**
 * Returns a workflow definition by id or undefined if not found.
 */
export function getWorkflowById(id: string): WorkflowDefinition | undefined {
  return workflows.find(wf => wf.id === id);
}