/**
 * Defines the shape of the environment variables used throughout the SDK.
 * All values are optional because they are read from process.env at runtime.
 */
export interface NexoraEnv {
  PORT?: number;
  NODE_ENV?: string;
  INTERNAL_API_KEY?: string;
  OPENAI_API_KEY?: string;
  N8N_WEBHOOK_URL?: string;
  // Optional integration keys – left undefined unless provided by the user.
  TIKTOK_API_KEY?: string;
  YOUTUBE_API_KEY?: string;
  PINTEREST_API_KEY?: string;
  CLICKBANK_API_KEY?: string;
  PARTNERSTACK_API_KEY?: string;
}

// Holds the cached environment so we don’t re‑parse on every call.
let cachedEnv: NexoraEnv | null = null;

/**
 * Reads the environment variables from `process.env` and returns a typed object.
 * Numeric values (like PORT) are parsed into numbers.  The result is cached on
 * first call to avoid repeated parsing.
 */
export function getEnv(): NexoraEnv {
  if (cachedEnv) return cachedEnv;
  const env: NexoraEnv = {
    PORT: process.env.PORT ? parseInt(process.env.PORT, 10) : undefined,
    NODE_ENV: process.env.NODE_ENV,
    INTERNAL_API_KEY: process.env.INTERNAL_API_KEY,
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    N8N_WEBHOOK_URL: process.env.N8N_WEBHOOK_URL,
    TIKTOK_API_KEY: process.env.TIKTOK_API_KEY,
    YOUTUBE_API_KEY: process.env.YOUTUBE_API_KEY,
    PINTEREST_API_KEY: process.env.PINTEREST_API_KEY,
    CLICKBANK_API_KEY: process.env.CLICKBANK_API_KEY,
    PARTNERSTACK_API_KEY: process.env.PARTNERSTACK_API_KEY
  };
  cachedEnv = env;
  return env;
}