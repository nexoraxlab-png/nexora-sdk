import express from 'express';
import type { Application } from 'express';
import { getEnv } from '../config';
import { createAuthMiddleware } from './middleware/auth';
import apiRouter from './routes';

const app: Application = express();

// Parse incoming JSON bodies
app.use(express.json());

// Health check endpoint – does not require authentication
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', version: '1' });
});

// Protect all /api routes with API key middleware
app.use('/api', createAuthMiddleware(), apiRouter);

// Start listening on the configured port
const { PORT } = getEnv();
const port = PORT || 4000;
app.listen(port, () => {
  console.log(`Nexora SDK server running on port ${port}`);
});

export default app;