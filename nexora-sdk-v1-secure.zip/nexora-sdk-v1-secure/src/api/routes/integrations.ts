import { Router } from 'express';
import * as tiktok from '../../integrations/tiktok';
import * as youtube from '../../integrations/youtube';
import * as pinterest from '../../integrations/pinterest';
import * as clickbank from '../../integrations/clickbank';
import * as partnerstack from '../../integrations/partnerstack';

const router = Router();

// TikTok publish endpoint
router.post('/tiktok/publish', async (req, res) => {
  try {
    const result = await tiktok.publish(req.body);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'TikTok publish failed' });
  }
});

// YouTube publish endpoint
router.post('/youtube/publish', async (req, res) => {
  try {
    const result = await youtube.publish(req.body);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'YouTube publish failed' });
  }
});

// Pinterest publish endpoint
router.post('/pinterest/publish', async (req, res) => {
  try {
    const result = await pinterest.publish(req.body);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Pinterest publish failed' });
  }
});

// ClickBank offers endpoint
router.get('/clickbank/offers', async (req, res) => {
  try {
    const result = await clickbank.getOffers(req.query);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'ClickBank offers fetch failed' });
  }
});

// PartnerStack programs endpoint
router.get('/partnerstack/programs', async (req, res) => {
  try {
    const result = await partnerstack.getPrograms(req.query);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'PartnerStack programs fetch failed' });
  }
});

export default router;