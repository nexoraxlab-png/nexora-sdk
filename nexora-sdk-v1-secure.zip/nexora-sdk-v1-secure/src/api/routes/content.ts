import { Router } from 'express';
import { generateAffiliateCaption } from '../../content/caption';
import { generateVideoScriptOutline } from '../../content/script';

const router = Router();

// Generates a short affiliate caption based on provided options
router.post('/caption', (req, res) => {
  const { productName, angle, platform } = req.body || {};
  if (!productName || !angle || !platform) {
    return res.status(400).json({ success: false, error: 'productName, angle and platform are required' });
  }
  const caption = generateAffiliateCaption({ productName, angle, platform });
  res.json({ success: true, data: caption });
});

// Generates a short video script outline
router.post('/script', (req, res) => {
  const { productName, durationSeconds } = req.body || {};
  if (!productName) {
    return res.status(400).json({ success: false, error: 'productName is required' });
  }
  const outline = generateVideoScriptOutline({ productName, durationSeconds });
  res.json({ success: true, data: outline });
});

export default router;