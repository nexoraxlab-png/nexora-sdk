import { Router } from 'express';
import workflowsRouter from './workflows';
import contentRouter from './content';
import integrationsRouter from './integrations';

const router = Router();

// Mount sub‑routers under their respective paths
router.use('/workflows', workflowsRouter);
router.use('/content', contentRouter);
router.use('/integrations', integrationsRouter);

export default router;