import { Router } from 'express';
import { listWorkflows, runWorkflowById } from '../../workflows/engine';

const router = Router();

// Returns a list of available workflow definitions
router.get('/', (req, res) => {
  const definitions = listWorkflows().map(def => ({
    id: def.id,
    name: def.name,
    description: def.description
  }));
  res.json({ success: true, data: definitions });
});

// Executes a workflow by id with an optional input payload
router.post('/execute', async (req, res) => {
  const { id, input } = req.body || {};
  if (!id) {
    return res.status(400).json({ success: false, error: 'Missing workflow id' });
  }
  try {
    const result = await runWorkflowById(id, input);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to execute workflow' });
  }
});

export default router;