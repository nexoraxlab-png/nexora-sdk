import { Request, Response, NextFunction } from 'express';
import { getEnv } from '../../config';

/**
 * Creates an authentication middleware for Express.  The middleware reads the
 * expected API key from the environment and compares it against the `x-api-key`
 * header on incoming requests.  If the keys do not match, a 401 response is
 * returned.  Otherwise the request is allowed to proceed.
 */
export function createAuthMiddleware() {
  const { INTERNAL_API_KEY } = getEnv();
  return (req: Request, res: Response, next: NextFunction): void => {
    const providedKey = req.header('x-api-key');
    if (!INTERNAL_API_KEY || providedKey !== INTERNAL_API_KEY) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }
    next();
  };
}