export { default as server } from './server';
export * from './middleware/auth';
export * as routes from './routes';