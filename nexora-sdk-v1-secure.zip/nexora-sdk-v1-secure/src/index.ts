// Main entry point for the Nexora SDK.  This file re‑exports all of the
// functional modules so that consumers can import them in one place.  It
// also exposes a constant identifying the SDK version.

export const NEXORA_SDK_VERSION = '1';

// Config API for reading environment variables
export * as config from './config';

// Utility helpers (logger, types, http client)
export * as utils from './utils/logger';
export * as types from './utils/types';
export * as http from './utils/httpClient';

// Express API (server and routers)
export * as api from './api';

// Workflows
export * as workflows from './workflows';

// Scheduling utilities
export * as scheduling from './scheduling';

// Content generation helpers
export * as content from './content';

// Third‑party integration wrappers
export * as integrations from './integrations';

// Automation triggers and orchestrator
export * as automation from './automation';