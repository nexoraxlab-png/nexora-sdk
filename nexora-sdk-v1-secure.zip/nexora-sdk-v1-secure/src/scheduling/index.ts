import cron from 'node-cron';
import { runWorkflowById } from '../workflows/engine';
import { logger } from '../utils/logger';

/**
 * Starts a recurring schedule that runs the affiliate content workflow at a
 * specified cron expression.  By default the workflow runs once per day at
 * midnight UTC.  The schedule immediately logs each execution.
 *
 * @param cronExpr Cron expression controlling execution timing
 */
export function startContentPublishingSchedule(cronExpr: string = '0 0 * * *'): void {
  logger.info('Starting content publishing schedule', { cron: cronExpr });
  cron.schedule(cronExpr, async () => {
    try {
      logger.info('Scheduled run triggered for affiliate-content-v1');
      const result = await runWorkflowById('affiliate-content-v1');
      logger.info('Scheduled workflow completed', { result });
    } catch (err: any) {
      logger.error('Scheduled workflow failed', { error: err.message });
    }
  });
}