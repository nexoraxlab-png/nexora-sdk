/**
 * Options for generating a video script outline.  The outline consists of a
 * series of short phrases representing different parts of the script.
 */
export interface VideoScriptOptions {
  productName: string;
  durationSeconds?: number;
}

/**
 * Generates a simple script outline for a promotional video.  The outline is
 * returned as an array of strings: hook, problem, solution, proof and call
 * to action.  No external APIs are called.
 */
export function generateVideoScriptOutline({
  productName,
  durationSeconds
}: VideoScriptOptions): string[] {
  const duration = durationSeconds || 30;
  const hook = `Hook: grab attention in the first 3 seconds with a bold statement about ${productName}.`;
  const problem = `Problem: describe a common issue your audience faces that ${productName} solves.`;
  const solution = `Solution: introduce ${productName} and explain how it addresses the problem.`;
  const proof = `Proof: share a quick testimonial or fact to build trust in ${productName}.`;
  const cta = `Call to Action: tell viewers what to do next (e.g., click the link) in the last 5 seconds.`;
  return [hook, problem, solution, proof, cta];
}