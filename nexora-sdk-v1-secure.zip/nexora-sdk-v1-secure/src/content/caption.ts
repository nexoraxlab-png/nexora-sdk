/**
 * Options for generating an affiliate caption.  The caption is a persuasive
 * multi‑line text that promotes the product on a specific platform with a
 * particular marketing angle.
 */
export interface AffiliateCaptionOptions {
  productName: string;
  angle: string;
  platform: string;
}

/**
 * Generates a multi‑line caption to promote an affiliate offer.  The content
 * incorporates the product name, marketing angle and platform‑specific call
 * to action.  No external APIs are called.
 */
export function generateAffiliateCaption({
  productName,
  angle,
  platform
}: AffiliateCaptionOptions): string {
  const lines: string[] = [];
  // Hook with product name and angle
  lines.push(`Discover ${productName} – ${angle}.`);
  lines.push(`Why wait? Unlock the benefits of ${productName} today!`);
  // Platform‑specific call to action
  const platformLower = platform.toLowerCase();
  let cta: string;
  switch (platformLower) {
    case 'tiktok':
      cta = 'Follow for more and tap the link in our bio to learn more!';
      break;
    case 'youtube':
      cta = 'Subscribe for more content and check the description for the link!';
      break;
    case 'pinterest':
      cta = 'Pin this for later and click through to shop now!';
      break;
    default:
      cta = 'Check out the link to get started now!';
  }
  lines.push(cta);
  return lines.join('\n');
}