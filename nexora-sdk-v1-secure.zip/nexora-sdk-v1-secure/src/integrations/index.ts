export * as tiktok from './tiktok';
export * as youtube from './youtube';
export * as pinterest from './pinterest';
export * as clickbank from './clickbank';
export * as partnerstack from './partnerstack';