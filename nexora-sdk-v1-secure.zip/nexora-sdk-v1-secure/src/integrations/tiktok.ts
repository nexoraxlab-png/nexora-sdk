import { getEnv } from '../config';
import { httpClient } from '../utils/httpClient';

export interface TikTokPublishPayload {
  [key: string]: any;
}

/**
 * Publishes content to TikTok by posting to the configured n8n webhook.  The
 * payload is sent unchanged.  Throws an error if the webhook URL is not
 * defined in the environment.
 */
export async function publish(payload: TikTokPublishPayload): Promise<any> {
  const { N8N_WEBHOOK_URL } = getEnv();
  if (!N8N_WEBHOOK_URL) {
    throw new Error('N8N_WEBHOOK_URL is not configured');
  }
  return httpClient.post<any>(N8N_WEBHOOK_URL, {
    platform: 'tiktok',
    action: 'publish',
    payload
  });
}