import { getEnv } from '../config';
import { httpClient } from '../utils/httpClient';

export interface ClickBankOfferParams {
  [key: string]: any;
}

/**
 * Retrieves affiliate offers from ClickBank by proxying the request to the n8n
 * webhook.  The response is expected to contain an `offers` array.  The
 * integration does not call ClickBank directly.
 */
export async function getOffers(params: ClickBankOfferParams = {}): Promise<any> {
  const { N8N_WEBHOOK_URL } = getEnv();
  if (!N8N_WEBHOOK_URL) {
    throw new Error('N8N_WEBHOOK_URL is not configured');
  }
  return httpClient.post<any>(N8N_WEBHOOK_URL, {
    platform: 'clickbank',
    action: 'offers',
    payload: params
  });
}