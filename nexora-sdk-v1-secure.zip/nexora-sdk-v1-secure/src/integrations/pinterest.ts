import { getEnv } from '../config';
import { httpClient } from '../utils/httpClient';

export interface PinterestPublishPayload {
  [key: string]: any;
}

/**
 * Publishes a pin to Pinterest using the configured n8n webhook.  No direct
 * API calls are made to Pinterest – the integration simply packages the
 * request and forwards it to your automation layer.
 */
export async function publish(payload: PinterestPublishPayload): Promise<any> {
  const { N8N_WEBHOOK_URL } = getEnv();
  if (!N8N_WEBHOOK_URL) {
    throw new Error('N8N_WEBHOOK_URL is not configured');
  }
  return httpClient.post<any>(N8N_WEBHOOK_URL, {
    platform: 'pinterest',
    action: 'publish',
    payload
  });
}