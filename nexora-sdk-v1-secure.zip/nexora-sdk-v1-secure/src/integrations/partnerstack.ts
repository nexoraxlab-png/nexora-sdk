import { getEnv } from '../config';
import { httpClient } from '../utils/httpClient';

export interface PartnerStackParams {
  [key: string]: any;
}

/**
 * Fetches available affiliate programs from PartnerStack via the n8n webhook.
 * Returns whatever the webhook returns.  Does not make any direct API calls.
 */
export async function getPrograms(params: PartnerStackParams = {}): Promise<any> {
  const { N8N_WEBHOOK_URL } = getEnv();
  if (!N8N_WEBHOOK_URL) {
    throw new Error('N8N_WEBHOOK_URL is not configured');
  }
  return httpClient.post<any>(N8N_WEBHOOK_URL, {
    platform: 'partnerstack',
    action: 'programs',
    payload: params
  });
}