import { getEnv } from '../config';
import { httpClient } from '../utils/httpClient';

export interface YouTubePublishPayload {
  [key: string]: any;
}

/**
 * Publishes a video to YouTube via the n8n webhook.  The SDK does not call
 * YouTube directly; it simply forwards the request to your automation flow.
 */
export async function publish(payload: YouTubePublishPayload): Promise<any> {
  const { N8N_WEBHOOK_URL } = getEnv();
  if (!N8N_WEBHOOK_URL) {
    throw new Error('N8N_WEBHOOK_URL is not configured');
  }
  return httpClient.post<any>(N8N_WEBHOOK_URL, {
    platform: 'youtube',
    action: 'publish',
    payload
  });
}