/**
 * A minimal JSON logger that writes structured logs to the console.  The logger
 * outputs four levels – debug, info, warn and error – each of which accepts a
 * message and optional metadata.  Metadata is merged into the log object.
 */
export interface LogMeta {
  [key: string]: unknown;
}

function log(level: string, message: string, meta?: LogMeta): void {
  const entry: Record<string, unknown> = { level, message, timestamp: new Date().toISOString() };
  if (meta && Object.keys(meta).length > 0) {
    entry.meta = meta;
  }
  // Use console.log for all levels so that JSON remains unbroken in stdout.
  console.log(JSON.stringify(entry));
}

export const logger = {
  debug: (message: string, meta?: LogMeta): void => log('debug', message, meta),
  info: (message: string, meta?: LogMeta): void => log('info', message, meta),
  warn: (message: string, meta?: LogMeta): void => log('warn', message, meta),
  error: (message: string, meta?: LogMeta): void => log('error', message, meta)
};