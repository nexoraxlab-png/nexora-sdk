import { logger } from './logger';

/**
 * A lightweight HTTP client built on top of the Fetch API available in Node.js 18+.
 * It automatically sets the `Content-Type` header to `application/json` and
 * serialises request bodies.  Responses are parsed as JSON when possible.
 */
export interface HttpClientOptions {
  headers?: Record<string, string>;
}

async function request<T>(
  method: string,
  url: string,
  body?: unknown,
  options: HttpClientOptions = {}
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };
  const fetchOptions: RequestInit = { method, headers };
  if (body !== undefined) {
    fetchOptions.body = JSON.stringify(body);
  }
  logger.debug(`HTTP ${method} ${url}`, { body });
  const response = await fetch(url, fetchOptions);
  const contentType = response.headers.get('content-type') || '';
  let data: any;
  if (contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = await response.text();
  }
  if (!response.ok) {
    const message = typeof data === 'string' ? data : JSON.stringify(data);
    throw new Error(`HTTP ${response.status}: ${message}`);
  }
  return data as T;
}

export const httpClient = {
  get: <T>(url: string, options?: HttpClientOptions): Promise<T> => request('GET', url, undefined, options),
  post: <T>(url: string, body: unknown, options?: HttpClientOptions): Promise<T> =>
    request('POST', url, body, options),
  put: <T>(url: string, body: unknown, options?: HttpClientOptions): Promise<T> =>
    request('PUT', url, body, options),
  delete: <T>(url: string, options?: HttpClientOptions): Promise<T> =>
    request('DELETE', url, undefined, options)
};