/**
 * Defines the types of automation events that can be emitted by external
 * systems.  Events are consumed by the automation orchestrator to trigger
 * workflows.
 */
export type AutomationEventType = 'NEW_OFFER' | 'SCHEDULED_RUN';

export interface AutomationEvent {
  type: AutomationEventType;
  data?: any;
}