import { AutomationEvent } from './triggers';
import { runWorkflowById } from '../workflows/engine';
import { startContentPublishingSchedule } from '../scheduling';
import { logger } from '../utils/logger';

/**
 * Creates an automation orchestrator that reacts to events and schedules
 * workflows.  When a `NEW_OFFER` or `SCHEDULED_RUN` event is received, the
 * orchestrator will run the affiliate content workflow.  It will also start
 * a recurring schedule at construction time.
 *
 * @param cronExpr Optional cron expression to override the default schedule
 */
export function createAutomationOrchestrator(cronExpr?: string) {
  // Start the recurring schedule immediately
  startContentPublishingSchedule(cronExpr);
  return {
    /**
     * Handles an automation event.  Supported event types trigger the
     * affiliate content workflow.  Unrecognised event types are ignored.
     */
    async handleEvent(event: AutomationEvent): Promise<void> {
      logger.info('Automation event received', { event });
      if (event.type === 'NEW_OFFER' || event.type === 'SCHEDULED_RUN') {
        try {
          await runWorkflowById('affiliate-content-v1', event.data);
        } catch (err: any) {
          logger.error('Error running workflow from automation event', { error: err.message });
        }
      }
    }
  };
}