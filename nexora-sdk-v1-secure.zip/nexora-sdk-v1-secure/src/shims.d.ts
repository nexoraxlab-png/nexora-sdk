/**
 * Shims for third‑party modules used by the SDK.  These declarations allow
 * TypeScript to compile without having the corresponding type definitions
 * installed.  The actual types will be provided when the user installs the
 * `@types/*` packages as dev dependencies.
 */
declare module 'express' {
  const exp: any;
  export default exp;
  // Export commonly used members as `any` types so that imports compile
  export const Router: any;
  export type Request = any;
  export type Response = any;
  export type NextFunction = any;
  export type Application = any;
}
declare module 'node-cron' {
  const cron: any;
  export default cron;
}
declare module 'uuid' {
  export function v4(): string;
}

// Provide a minimal declaration for the global `process` variable so that
// referencing `process.env` does not cause a compiler error when @types/node
// is not installed.
declare var process: {
  env: Record<string, string | undefined>;
};